# 研究筆記索引

- [積極同意如何轉化為性健康教育內容？](affirmative-consent-note.md)：待審閱，只使用 SRC-0001。
