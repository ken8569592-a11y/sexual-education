---
title: "積極同意如何轉化為性健康教育內容？"
type: note
status: needs-review
created: 2026-11-03
updated: 2026-11-03
source_ids: [SRC-0001]
wiki_snapshot_date: 2026-11-03
reviewed_by: null
reviewed_at: null
---
# 積極同意如何轉化為性健康教育內容？

## 問題與範圍
依目前 Wiki，整理積極同意的教育重點與限制，作為成年讀者的入門教材草稿。不是現行法律說明、系統性回顧或研究效果結論。

## 使用的 Wiki 快照
- [性同意與溝通](../../wiki/topics/sexual-consent.md)，更新 2026-11-03。
- [積極同意](../../wiki/concepts/affirmative-consent.md)，更新 2026-11-03。
- [SRC-0001 來源摘要](../../wiki/sources/lin-wu-2018-affirmative-consent.md)，更新 2026-11-03。
上述均待審閱。完整檔案 SHA-256 見本筆記的 .sources.json。

## 核心論述
### 自願與確認
積極同意重視清楚意識下、自願且肯定的意願，不能只從沉默、未反抗或情境猜測同意。應留意欺瞞、壓迫與權力關係。[SRC-0001，pp.23–24、28]

### 活動與時間的特定性
同意一項活動，不等於同意其他活動；一次同意不代表之後仍同意。[SRC-0001，p.24]

### 可撤回與持續確認
開始之後仍能改變心意。不因親密關係、婚姻或過往經驗推定持續意願。[SRC-0001，pp.24、28]

### 教育方向
依作者建議，教育可培養表達需求與尊重他人界線，避免把防止性暴力的責任交給受害者。[SRC-0001，pp.26–28]

## 教學轉譯
Wiki 已有情境：「我想停」時先停止；願意親吻不等於願意所有活動。可練習提問「你現在還想繼續嗎？」這些是教學轉譯，非原文個案或已驗證介入。
反思題：「你會如何回應對方改變心意？」為本次編排，不是量表題目。

## 證據限制
只有一篇倡議評論，不能推論特定課程會降低性暴力。文中2017年調查為二手轉述，不能當成2026年人口或MSM的估計。2018年法制敘述不得作現行法結論。尚不足以支持性同意與性傳染病風險的因果論述。

## 已使用文獻
林美薰、吳姿瑩（2018）。沒有同意就是性侵（only YES means YES）──全球女權運動「積極同意」的倡議、教育與立法推動。《婦研縱橫》，108，20–29。https://doi.org/10.6256/FWGS.2018.108.20

## 建議參考文獻：尚未納入 Wiki
以下僅為搜尋所得的待匯入候選資料，沒有用於上方正文或簡報。查核日期：2026-11-03。非同儕審查實證論文，不能取代研究效果證據。

### REF-0001
UNESCO、UNAIDS、UNFPA、UNICEF、UN Women、WHO（2018）。International technical guidance on sexuality education: An evidence-informed approach。

推薦理由：供後續補充性教育課程與學習目標時評估。

[開啟／下載 PDF](https://myanmar.unfpa.org/sites/default/files/pub-pdf/260770eng.pdf)；[出版機構頁面](https://www.who.int/publications/m/item/9789231002595)。已確認 PDF 可讀；尚未完整閱讀、匯入或審閱。下載至私人 raw 後，依 ingest 流程處理。

### REF-0002
National Sexual Violence Resource Center（2019）。Your Consent Guide。

推薦理由：供後續評估溝通情境與教學素材。

[開啟／下載 PDF](https://www.nsvrc.org/wp-content/uploads/2021/02/YourConsentGuide2020_Final508.pdf)；[出版機構頁面](https://www.nsvrc.org/resource/your-consent-guide/)。已確認 PDF 可讀；尚未完整閱讀、匯入或審閱。下載至私人 raw 後，依 ingest 流程處理。
