# HTML 簡報

直接開啟 [簡報](../../site/presentation.html)。完整展示資產集中於 site，避免複製公式引擎。

鍵盤左右鍵、Home、End、N 講稿、F 全螢幕。手機可用按鈕翻頁。列印選擇橫式。
